package com.gme.hom.sdn.ofac.models.sanctions;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlTransient;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element name="IDRegDocument" type="{http://www.un.org/sanctions/1.0}IDRegDocumentSchemaType" maxOccurs="unbounded" minOccurs="0"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(name = "", propOrder = {
//    "idRegDocument"
//})
@Entity
@Getter
@Setter
public class IDRegDocuments {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "id_reg_documents_seq", sequenceName = "id_reg_documents_seq", allocationSize = 1)
    @XmlTransient
    private Long id;

//    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
//    @XmlElement(name = "IDRegDocument")
//    protected List<IDRegDocumentSchemaType> idRegDocument;


//    public List<IDRegDocumentSchemaType> getIDRegDocument() {
//        if (idRegDocument == null) {
//            idRegDocument = new ArrayList<>();
//        }
//        return this.idRegDocument;
//    }

}

