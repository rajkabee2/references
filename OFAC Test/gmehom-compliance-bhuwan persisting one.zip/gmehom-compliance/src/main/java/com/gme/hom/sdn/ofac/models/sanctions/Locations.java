package com.gme.hom.sdn.ofac.models.sanctions;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlTransient;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element name="Location" type="{http://www.un.org/sanctions/1.0}LocationSchemaType" maxOccurs="unbounded" minOccurs="0"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(name = "", propOrder = {
//    "location"
//})
@Entity
@Getter
@Setter
public class Locations {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "locations_seq", sequenceName = "locations_seq", allocationSize = 1)
    @XmlTransient
    private Long id;

//    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
//    @XmlElement(name = "Location")
//    protected List<LocationSchemaType> location;


//    public List<LocationSchemaType> getLocation() {
//        if (location == null) {
//            location = new ArrayList<>();
//        }
//        return this.location;
//    }

}

