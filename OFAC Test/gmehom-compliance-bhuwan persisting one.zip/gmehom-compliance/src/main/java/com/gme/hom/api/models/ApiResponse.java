package com.gme.hom.api.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.gme.hom.api.config.ApiDataTypeCodes;
import com.gme.hom.api.config.ApiResponseCodes;
import com.gme.hom.api.config.ApiResponseScopeCodes;
import com.gme.hom.api.config.ApiStatusCodes;
import com.gme.hom.auth.models.AuthValidationResponse;
import com.gme.hom.messaging.models.MessageResponse;
import com.gme.hom.testService.models.TestResponse;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApiResponse {

	@NotNull
	@Enumerated(EnumType.STRING)
	@JsonInclude(Include.NON_NULL)
	private ApiResponseCodes status;
	
	@JsonProperty("status_code")
	@JsonInclude(Include.NON_NULL)
	private ApiStatusCodes statusCode;


	@Enumerated(EnumType.STRING)
	@JsonInclude(Include.NON_NULL)
	private ApiResponseScopeCodes scope;

	@JsonInclude(Include.NON_NULL)
	private String description;

	@JsonInclude(Include.NON_NULL)
	private String message;

	@Enumerated(EnumType.STRING)
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("data_type")
	private ApiDataTypeCodes dataType;

//	@JsonInclude(Include.NON_NULL)
//	private Object data;	
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("auth_validation")
	private AuthValidationResponse authValidationResponse;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("message_response")
	private MessageResponse messageResponse;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("test")
	private TestResponse testResponse;

}
