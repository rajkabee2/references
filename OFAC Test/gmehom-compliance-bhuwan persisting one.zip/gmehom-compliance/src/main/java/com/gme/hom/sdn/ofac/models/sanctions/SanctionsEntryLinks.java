package com.gme.hom.sdn.ofac.models.sanctions;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlTransient;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element name="SanctionsEntryLink" type="{http://www.un.org/sanctions/1.0}SanctionsEntryLinkSchemaType" maxOccurs="unbounded" minOccurs="0"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(name = "", propOrder = {
//    "sanctionsEntryLink"
//})
@Entity
@Getter
@Setter
public class SanctionsEntryLinks {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "sanctions_entry_links_seq", sequenceName = "sanctions_entry_links_seq", allocationSize = 1)
    @XmlTransient
    private Long id;

//    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
//    @XmlElement(name = "SanctionsEntryLink")
//    protected List<SanctionsEntryLinkSchemaType> sanctionsEntryLink;
//
//
//    public List<SanctionsEntryLinkSchemaType> getSanctionsEntryLink() {
//        if (sanctionsEntryLink == null) {
//            sanctionsEntryLink = new ArrayList<>();
//        }
//        return this.sanctionsEntryLink;
//    }

}
