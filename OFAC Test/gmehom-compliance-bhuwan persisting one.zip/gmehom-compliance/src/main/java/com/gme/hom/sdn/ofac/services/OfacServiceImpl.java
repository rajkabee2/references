package com.gme.hom.sdn.ofac.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.gme.hom.GlobalConfig;
import com.gme.hom.sdn.ofac.models.sanctions.Sanctions;
import com.gme.hom.sdn.ofac.repositories.SansactionRepository;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;

@Service
public class OfacServiceImpl implements OfacService {

	@Autowired
	GlobalConfig globalConfig;

	@Autowired
	SansactionRepository sansactionRepository;

	Logger logger = LoggerFactory.getLogger(OfacServiceImpl.class);

	public void loadXml() {

		ObjectMapper xmlMapper = new XmlMapper();
		try {

			FileInputStream fis = new FileInputStream(globalConfig.gmeHomServicesSdnOfacXmlPath);

			String xml = IOUtils.toString(fis, "UTF-8");

			JAXBContext jaxbContext = JAXBContext.newInstance(Sanctions.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

			StringReader reader = new StringReader(xml);

			Sanctions sanctions = (Sanctions) unmarshaller.unmarshal(reader);
			Sanctions sanctions1 =  sansactionRepository.save(sanctions);
			System.out.println(sanctions1);

//			logger.debug("OFAC version: {}", sanctions.getVersion());
//			logger.debug("Date of issue: {}/{}/{}", sanctions.getDateOfIssue().getMonth(),
//					sanctions.getDateOfIssue().getDay(), sanctions.getDateOfIssue().getYear());

		} catch (IOException | JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // serializing

	}

}
