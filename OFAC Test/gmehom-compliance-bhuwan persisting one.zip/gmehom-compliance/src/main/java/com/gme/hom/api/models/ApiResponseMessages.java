package com.gme.hom.api.models;

public enum ApiResponseMessages {
	// OTP
	PHONE_ADDED_CHECK_OTP("The phone number has been added. Please check for OTP message."),
	
	// passwords
	PASSWORD_DIDNOT_MATCH("Passwords did not match. Please try again."),
	PASSWORD_SET_SUCCESSFULLY("Password set successfully."),
	
	// data not available
	NOT_AVAILABLE("Not available.")
	;
	

	private final String name;

	private ApiResponseMessages(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}

}
