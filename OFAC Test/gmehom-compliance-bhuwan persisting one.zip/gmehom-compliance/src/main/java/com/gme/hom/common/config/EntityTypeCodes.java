package com.gme.hom.common.config;

public enum EntityTypeCodes {
	MERCHANT("MERCHANT"),
	USER_SIGNUP("USER_SIGNUP"),
	USERS("USERS"),
	CATEGORIES("CATEGORIES");
	
	private final String name;

	private EntityTypeCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}
	

}
