package com.gme.hom.api.config;

public enum ApiServiceCodes {
	
	ADMIN("admin"),
	AUTH("auth"),
	DOCUMENTS("documents"),
	MERCHANT("merchant"),
	MESSAGING("messaging"),
	PARTNERS("partners"),
	TRANSACTIONS("transactions");
	
	private final String name;

	private ApiServiceCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}

}
