package com.gme.hom.messaging.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.gme.hom.GlobalConfig;
import com.gme.hom.api.config.ApiFunctionCodes;
import com.gme.hom.api.config.ApiResponseCodes;
import com.gme.hom.api.config.ApiServiceCodes;
import com.gme.hom.api.internal.services.ApiConsumerService;
import com.gme.hom.api.models.ApiData;
import com.gme.hom.api.models.ApiRequest;
import com.gme.hom.api.models.ApiResponse;
import com.gme.hom.messaging.config.MessageStatusCodes;
import com.gme.hom.messaging.models.MessageBody;
import com.gme.hom.messaging.models.MessageRequest;
import com.gme.hom.messaging.models.MessageResponse;

import jakarta.servlet.http.Cookie;

@Service
public class MessagingServiceImpl implements MessagingService {

	final ApiConsumerService apiConsumer;
	final GlobalConfig globalConfig;

	private static final Logger logger = LoggerFactory.getLogger(MessagingServiceImpl.class);

	MessagingServiceImpl(ApiConsumerService apiConsumer, GlobalConfig globalConfig) {
		this.apiConsumer = apiConsumer;
		this.globalConfig = globalConfig;
	}

	public MessageResponse sendMessage(MessageRequest messageRequest, MessageBody messageBody) {
		MessageResponse mRes = new MessageResponse();

		logger.debug("-->" + new Object() {
		}.getClass().getName() + ":" + new Object() {
		}.getClass().getEnclosingMethod().getName());
		logger.debug(String.valueOf(messageRequest));
		logger.debug(String.valueOf(messageBody));

		ApiRequest apiReq = new ApiRequest();

		ApiData apiData = new ApiData();
		apiData.setMessageRequest(messageRequest);
		apiData.setMessageBody(messageBody);

		apiReq.setData(apiData);
		apiReq.setFunction(ApiFunctionCodes.SEND_MESSAGE);

		// setting dev key for automated service
		apiReq.setDevKey(globalConfig.gmeDevKey);

		// no cookies required for auth service as client
		Cookie cookies[] = new Cookie[0];

		ApiResponse apiRes = apiConsumer.consumeApi(cookies, ApiServiceCodes.MESSAGING, apiReq);

		if (apiRes != null) {
			logger.debug("Response from API ...");
			logger.debug(String.valueOf(apiRes));

			if (apiRes.getStatus() == ApiResponseCodes.SUCCESS) {
				logger.debug("Value of apiRes.getMessageResponse():" + String.valueOf(apiRes.getMessageResponse()));

				mRes = apiRes.getMessageResponse();

			}
		} else {
			mRes.setMessagingStatus(MessageStatusCodes.UNSUCCESSFUL);
		}

		return mRes;
	};

}
