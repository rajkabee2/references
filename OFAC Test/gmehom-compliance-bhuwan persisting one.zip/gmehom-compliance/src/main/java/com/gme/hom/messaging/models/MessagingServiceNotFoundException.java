package com.gme.hom.messaging.models;

public class MessagingServiceNotFoundException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8762742454330597957L;

	public MessagingServiceNotFoundException(String message) {
		
		super(message);
		
	}

}
