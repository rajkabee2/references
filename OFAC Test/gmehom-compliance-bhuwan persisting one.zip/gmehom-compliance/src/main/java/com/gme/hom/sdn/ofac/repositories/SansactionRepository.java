package com.gme.hom.sdn.ofac.repositories;

import com.gme.hom.sdn.ofac.models.sanctions.Sanctions;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SansactionRepository extends JpaRepository<Sanctions, Long> {
}
