package com.gme.hom.common.services;

import java.util.List;
import java.util.StringJoiner;

public final class CustomStringJoiner {

	public static final String joinStrings(List<Object> strings, String separator) {
		StringJoiner sJoiner = new StringJoiner(separator);
		for (Object string : strings) {
			sJoiner.add((String) string);
		}
		return sJoiner.toString();
	}
}
