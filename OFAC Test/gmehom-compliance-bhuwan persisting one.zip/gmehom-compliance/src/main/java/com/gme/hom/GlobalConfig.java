package com.gme.hom;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ConfigurationProperties
//@PropertySource("file:/app/gmehom-compliance/application.properties")
 @PropertySource("application.properties")
public class GlobalConfig {

	@Value("${gme.orgname}")
	public String gmeOrgname;

	@Value("${gme.system}")
	public String gmeSystem;	
	
	@Value("${gme.data.entity.hash.algo}")
	public String gmeDataEntityHashAlgo;
	
	@Value("${gme.data.row.hash.algo}")
	public String gmeDataRowHashAlgo;
	
	@Value("${gme.hom.services.auth.url}")
	public String gmeHomServicesAuthUrl;
	
	@Value("${gme.dev.key}")
	public String gmeDevKey;	
	
	@Value("${gme.hom.services.apigateway.url}")
	public String gmeHomServicesApigatewayUrl;
	
	@Value("${gme.hom.services.messaging.name}")
	public String gmeHomServicesMessagingName;
	
	@Value("${gme.hom.services.sdn.ofac.xml.path}")
	public String gmeHomServicesSdnOfacXmlPath;
	          	
}
