package com.gme.hom.api.config;

public enum ApiDataTypeCodes {

	LONG("LONG"), CATEGORY("CATEGORY"), EXCHANGE_RATE("EXCHANGE_RATE"), USER("USER");
	private final String name;

	private ApiDataTypeCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}
}
