package com.gme.hom.sdn.ofac.models.sanctions;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlTransient;
import lombok.Getter;
import lombok.Setter;


//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(name = "", propOrder = {
//    "distinctParty"
//})
@Entity
@Getter
@Setter
public class DistinctParties {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "distinct_parties_seq", sequenceName = "distinct_parties_seq", allocationSize = 1)
    @XmlTransient
    private Long id;

//    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
//    @XmlElement(name = "DistinctParty")
//    protected List<DistinctPartySchemaType> distinctParty;
//
//
//    public List<DistinctPartySchemaType> getDistinctParty() {
//        if (distinctParty == null) {
//            distinctParty = new ArrayList<>();
//        }
//        return this.distinctParty;
//    }

}


