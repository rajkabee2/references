package com.gme.hom.sdn.ofac.models.sanctions;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlTransient;
import lombok.Getter;
import lombok.Setter;


//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(name = "", propOrder = {
//    "sanctionsEntry"
//})
@Entity
@Getter
@Setter
public class SanctionsEntries {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "sanctions_entries_seq", sequenceName = "sanctions_entries_seq", allocationSize = 1)
    @XmlTransient
    private Long id;

//    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
//    @XmlElement(name = "SanctionsEntry")
//    protected List<SanctionsEntrySchemaType> sanctionsEntry;
//
//
//    public List<SanctionsEntrySchemaType> getSanctionsEntry() {
//        if (sanctionsEntry == null) {
//            sanctionsEntry = new ArrayList<>();
//        }
//        return this.sanctionsEntry;
//    }

}
