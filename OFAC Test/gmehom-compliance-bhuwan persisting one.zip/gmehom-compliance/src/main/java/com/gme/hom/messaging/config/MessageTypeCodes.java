package com.gme.hom.messaging.config;

public enum MessageTypeCodes {
	
	EMAIL("EMAIL"),
	SMS("SMS"),
	NOTIFICATION("NOTIFICATION");
	
	private final String name;

	private MessageTypeCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}
}
