package com.gme.hom.security.services;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordService {

	static String passwordRegex = "^(?=.*[0-9])" 
			+ "(?=.*[a-z])(?=.*[A-Z])" 
			+ "(?=.*[@#$%^&+=])" 
			+ "(?=\\S+$).{8,20}$";

	public static String generateRandomPassword() {
		int passwordLength = 8;
		StringBuilder password = new StringBuilder();

		Random random = new Random();
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+";

		for (int i = 0; i < passwordLength; i++) {
			int index = random.nextInt(characters.length());
			password.append(characters.charAt(index));
		}

		return password.toString();
	}

	public static boolean validatePassword(String password) {

		if (password != null && password.length() != 0) {
			
			Pattern p = Pattern.compile(passwordRegex);			
			Matcher m = p.matcher(password);			
			if(m.matches()){
				return true;	
			}	
			
		}
		return false;
		
	}

}
