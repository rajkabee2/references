package com.gme.hom.common.models;

public final class FunctionReturnCodes {

	public static final boolean SUCCESS = true;
	public static final boolean FAIL = false;
	
	
}
