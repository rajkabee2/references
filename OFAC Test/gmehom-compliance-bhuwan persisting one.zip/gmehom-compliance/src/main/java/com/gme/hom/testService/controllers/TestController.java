package com.gme.hom.testService.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gme.hom.GlobalConfig;
import com.gme.hom.api.config.ApiResponseCodes;
import com.gme.hom.api.models.ApiResponse;
import com.gme.hom.testService.models.TestResponse;
import com.gme.hom.testService.services.TestService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/*
 * A test controller with test endpoints
 */
@RestController
@RequestMapping("/test")
public class TestController {

	// for dependency injection
	@Autowired
	private TestService testService;

	@Autowired
	private GlobalConfig globalConfig;

	// Logger logger = LoggerFactory.getLogger(TestController.class);

	/*
	 * Default end-point When running as application: access using
	 * http://localhost:8080
	 */
	@GetMapping("")
	public ResponseEntity<ApiResponse> index(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
		// logger.debug("Test controller");
		ApiResponse ar = new ApiResponse();

		// MqttRequest mr = new MqttRequest("hello", "there");
		// mqttService.sendNotification(mr);

		TestResponse tr = new TestResponse();
		tr.setOrg(globalConfig.gmeOrgname);
		tr.setSystem(globalConfig.gmeSystem);
		tr.setCounter(testService.getCounter());

		ar.setStatus(ApiResponseCodes.SUCCESS);

		ar.setDescription("Test service");

		ar.setTestResponse(tr);

		return ResponseEntity.ok(ar);

	}

	@PostMapping("")
	public ResponseEntity<ApiResponse> indexPost(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {

		// logger.debug("Test controller");
		ApiResponse ar = new ApiResponse();

		// MqttRequest mr = new MqttRequest("hello", "there");
		// mqttService.sendNotification(mr);

		ar.setStatus(ApiResponseCodes.SUCCESS);

		ar.setDescription(new Object() {
		}.getClass().getName() + ":" + new Object() {
		}.getClass().getEnclosingMethod().getName());

		return ResponseEntity.ok(ar);

	}

}
