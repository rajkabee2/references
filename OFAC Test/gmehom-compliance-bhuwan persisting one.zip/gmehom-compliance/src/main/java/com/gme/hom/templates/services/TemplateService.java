package com.gme.hom.templates.services;

import java.util.List;

import com.gme.hom.messaging.config.MessageTypeCodes;
import com.gme.hom.templates.config.MessageTemplateTypeCodes;
import com.gme.hom.templates.repository.TemplateDto;

public interface TemplateService {

	List<TemplateDto> getAllTemplates();

	TemplateDto getTemplateByTypeAndPurpose(MessageTypeCodes templateType, MessageTemplateTypeCodes purpose);	

}
