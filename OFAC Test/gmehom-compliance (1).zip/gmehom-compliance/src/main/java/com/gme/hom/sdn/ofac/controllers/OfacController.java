package com.gme.hom.sdn.ofac.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gme.hom.api.models.ApiRequest;
import com.gme.hom.api.models.ApiResponse;
import com.gme.hom.sdn.ofac.services.OfacService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/compliance/sdn/ofac")
public class OfacController {

	@Autowired
	OfacService ofacService;

	Logger logger = LoggerFactory.getLogger(OfacController.class);

	@PostMapping("")
	public ResponseEntity<ApiResponse> ofacRequestHandler(@Valid @RequestBody ApiRequest apiRequest,
			HttpServletRequest httpRequest, HttpServletResponse httpResponse) {

		logger.debug("-->" + new Object() {
		}.getClass().getName() + ":" + new Object() {
		}.getClass().getEnclosingMethod().getName());
		logger.debug(String.valueOf(apiRequest));
		
		
		ApiResponse apiResponse = new ApiResponse();
		
		ofacService.loadXml();
		
		
		return ResponseEntity.ok(apiResponse);

	}

}
