


package com.gme.hom.sdn.ofac.models.sanctionsEntrySchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.config.EntryDeltaFlagSchemaType;
import com.gme.hom.sdn.ofac.models.Comment;
import com.gme.hom.sdn.ofac.models.ProfileRelationshipReference;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SanctionsEntrySchemaType", propOrder = {
    "comment",
    "limitationsToListing",
    "entryEvent",
    "sanctionsMeasure",
    "supportingInfo",
    "profileRelationshipReference"
})
@Entity
@Getter
@Setter
public class SanctionsEntrySchemaType {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
    @SequenceGenerator(name="sanctions_entry_sequence",sequenceName="sanctions_entry_sequence",allocationSize = 1)
	@XmlAttribute(name = "ID", required = true)
	@XmlSchemaType(name = "nonNegativeInteger")
	protected Long id;
    @Embedded
    @XmlElement(name = "Comment")
    protected Comment comment;
    @XmlElement(name = "LimitationsToListing")
    protected LimitationsToListing limitationsToListing;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "EntryEvent", required = true)
    protected List<EntryEvent> entryEvent;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "SanctionsMeasure", required = true)
    protected List<SanctionsMeasure> sanctionsMeasure;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "SupportingInfo")
    protected List<SupportingInfo> supportingInfo;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "ProfileRelationshipReference")
    protected List<ProfileRelationshipReference> profileRelationshipReference;
    @XmlAttribute(name = "ProfileID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected Long profileID;
    @XmlAttribute(name = "ListID")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected Long listID;
    @XmlAttribute(name = "EntryProfileRef")
    protected String entryProfileRef;
    @XmlAttribute(name = "EntryDeltaFlag")
    protected EntryDeltaFlagSchemaType entryDeltaFlag;
    @XmlAttribute(name = "DeltaAction")
    @Enumerated(EnumType.STRING)
    @Column(insertable = false, updatable = false)
    protected DeltaActionSchemaType deltaAction;





    public List<EntryEvent> getEntryEvent() {
        if (entryEvent == null) {
            entryEvent = new ArrayList<>();
        }
        return this.entryEvent;
    }


    public List<SanctionsMeasure> getSanctionsMeasure() {
        if (sanctionsMeasure == null) {
            sanctionsMeasure = new ArrayList<>();
        }
        return this.sanctionsMeasure;
    }


    public List<SupportingInfo> getSupportingInfo() {
        if (supportingInfo == null) {
            supportingInfo = new ArrayList<>();
        }
        return this.supportingInfo;
    }


    public List<ProfileRelationshipReference> getProfileRelationshipReference() {
        if (profileRelationshipReference == null) {
            profileRelationshipReference = new ArrayList<>();
        }
        return this.profileRelationshipReference;
    }

    











}
