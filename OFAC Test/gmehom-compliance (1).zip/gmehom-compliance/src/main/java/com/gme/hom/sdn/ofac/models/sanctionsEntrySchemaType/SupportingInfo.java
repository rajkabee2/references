package com.gme.hom.sdn.ofac.models.sanctionsEntrySchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.DirectURL;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element name="Text" minOccurs="0">
 *           <complexType>
 *             <simpleContent>
 *               <extension base="<http://www.w3.org/2001/XMLSchema>string">
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </extension>
 *             </simpleContent>
 *           </complexType>
 *         </element>
 *         <element ref="{http://www.un.org/sanctions/1.0}DirectURL" minOccurs="0"/>
 *       </sequence>
 *       <attribute name="ID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="SupInfoTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "text",
    "directURL"
})
@Entity
@Getter
@Setter
public class SupportingInfo {

    @XmlElement(name = "Text")
    protected Text text;
    @Embedded
    @XmlElement(name = "DirectURL")
    protected DirectURL directURL;
    @XmlAttribute(name = "ID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "supporting_info_seq", sequenceName = "supporting_info_seq", allocationSize = 1)
    protected Long id;
    @XmlAttribute(name = "SupInfoTypeID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected Long supInfoTypeID;
    @XmlAttribute(name = "DeltaAction")
    @Column(insertable = false, updatable = false)
    protected DeltaActionSchemaType deltaAction;

   


    

}