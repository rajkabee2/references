package com.gme.hom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@ComponentScan
@SpringBootApplication
public class GmeHoMComplianceApplication {

	public static void main(String[] args) {	
		System.setProperty("javax.net.ssl.trustStore", "/app/gmehom-apigateway/gmehomkey.jks");
		System.setProperty("javax.net.ssl.trustStorePassword", "w!nterc@stle");
		SpringApplication.run(GmeHoMComplianceApplication.class, args);
	}
}
