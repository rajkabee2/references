package com.gme.hom.sdn.ofac.models.identitySchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "masterNamePartGroup"
})
@Entity
@Getter @Setter
public class NamePartGroups {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "MasterNamePartGroup", required = true)
    protected List<MasterNamePartGroup> masterNamePartGroup;
    @XmlAttribute(name = "DeltaAction")
    protected DeltaActionSchemaType deltaAction;


    public List<MasterNamePartGroup> getMasterNamePartGroup() {
        if (masterNamePartGroup == null) {
            masterNamePartGroup = new ArrayList<>();
        }
        return this.masterNamePartGroup;
    }




   

}
