package com.gme.hom.api.models;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.gme.hom.api.config.ApiFunctionCodes;
import com.gme.hom.api.config.ApiScopeCodes;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.Valid;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ApiRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3866610636920677597L;

	@Enumerated(EnumType.STRING)
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value="function", required=true)
	private ApiFunctionCodes function;

	@Enumerated(EnumType.STRING)
	@JsonInclude(Include.NON_NULL)
	private ApiScopeCodes scope;

	@Valid
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value="data")
	private ApiData data;

	@JsonInclude(Include.NON_NULL)
	private String description;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value="dev_key")
	private String devKey;

}
