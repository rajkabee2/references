package com.gme.hom.sdn.ofac.models.distinctPartySchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.Comment;
import com.gme.hom.sdn.ofac.models.DirectURL;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element ref="{http://www.un.org/sanctions/1.0}Comment" minOccurs="0"/>
 *         <element name="ExRefValue" minOccurs="0">
 *           <complexType>
 *             <simpleContent>
 *               <extension base="<http://www.w3.org/2001/XMLSchema>string">
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </extension>
 *             </simpleContent>
 *           </complexType>
 *         </element>
 *         <element ref="{http://www.un.org/sanctions/1.0}DirectURL" minOccurs="0"/>
 *         <element name="SubLink" maxOccurs="unbounded" minOccurs="0">
 *           <complexType>
 *             <complexContent>
 *               <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 <sequence>
 *                   <element name="Description" minOccurs="0">
 *                     <complexType>
 *                       <simpleContent>
 *                         <extension base="<http://www.w3.org/2001/XMLSchema>string">
 *                           <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *                         </extension>
 *                       </simpleContent>
 *                     </complexType>
 *                   </element>
 *                   <element ref="{http://www.un.org/sanctions/1.0}DirectURL"/>
 *                 </sequence>
 *                 <attribute name="TargetTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </restriction>
 *             </complexContent>
 *           </complexType>
 *         </element>
 *       </sequence>
 *       <attribute name="ExRefTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "comment",
    "exRefValue",
    "directURL",
    "subLink"
})
@Entity
@Getter
@Setter
public class ExternalReference {

    @XmlElement(name = "Comment")
    @Embedded
    protected Comment comment;
    @Embedded
    @XmlElement(name = "ExRefValue")
    protected ExRefValue exRefValue;

    @Embedded
    @XmlElement(name = "DirectURL")
    protected DirectURL directURL;

    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "SubLink")
    protected List<SubLink> subLink;
    @XmlAttribute(name = "ExRefTypeID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    protected Long exRefTypeID;
    @XmlAttribute(name = "DeltaAction")
    @Column(insertable = false, updatable = false)
    protected DeltaActionSchemaType deltaAction;

 
   

 


    public List<SubLink> getSubLink() {
        if (subLink == null) {
            subLink = new ArrayList<>();
        }
        return this.subLink;
    }

   


    


   

}
