package com.gme.hom.api.config;

public enum ApiStatusCodes {
	R("RETRY"), F("FAILURE"), S("SUCCESS");

	private final String name;

	private ApiStatusCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}

}
