package com.gme.hom.api.config;

public enum ApiResponseScopeCodes {
	
	SINGLE("SINGLE"),
	MULTIPLE("MULTIPLE");
	
	private final String name;

	private ApiResponseScopeCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}

}
