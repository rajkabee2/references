package com.gme.hom.sdn.ofac.models.documentedNameSchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.Comment;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "comment" })
@Entity
@Getter
@Setter
public class DocumentedNameCountry {

	@Embedded
	@XmlElement(name = "Comment")
	protected Comment comment;
	@XmlAttribute(name = "CountryID", required = true)
	@XmlSchemaType(name = "nonNegativeInteger")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	protected Long countryID;
	@XmlAttribute(name = "DeltaAction")
	@Column(insertable = false, updatable = false)
	protected DeltaActionSchemaType deltaAction;

	

}

