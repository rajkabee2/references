package com.gme.hom.sdn.ofac.models.referenceValueSetSchemaType;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "calendarType"
})
@Entity
@Getter
@Setter
public class CalendarTypeValues {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "CalendarType")
    protected java.util.List<CalendarType> calendarType;


    public java.util.List<CalendarType> getCalendarType() {
        if (calendarType == null) {
            calendarType = new ArrayList<>();
        }
        return this.calendarType;
    }



}