package com.gme.hom.common.models;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.gme.hom.common.config.EntityTypeCodes;

public final class EntityTables {
	
	public static final Map<EntityTypeCodes, String> entityTables;
	static {
		Map<EntityTypeCodes, String> newMap = new HashMap<EntityTypeCodes, String>();
		newMap.put(EntityTypeCodes.MERCHANT, "merchants");
		newMap.put(EntityTypeCodes.USER_SIGNUP, "users_signup");	
		newMap.put(EntityTypeCodes.USERS, "users");
		newMap.put(EntityTypeCodes.CATEGORIES, "category_roots");
		entityTables = Collections.unmodifiableMap(newMap);
	}
	
	
}
