package com.gme.hom.sdn.ofac.models.distinctPartySchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.DirectURL;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;

import static jakarta.persistence.GenerationType.SEQUENCE;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element name="Description" minOccurs="0">
 *           <complexType>
 *             <simpleContent>
 *               <extension base="<http://www.w3.org/2001/XMLSchema>string">
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </extension>
 *             </simpleContent>
 *           </complexType>
 *         </element>
 *         <element ref="{http://www.un.org/sanctions/1.0}DirectURL"/>
 *       </sequence>
 *       <attribute name="TargetTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "description",
    "directURL"
})
@Entity
@Getter
@Setter
public class SubLink {

    @Embedded
    @XmlElement(name = "Description")
    protected Description description;
    @Embedded
    @XmlElement(name = "DirectURL", required = true)
    protected DirectURL directURL;
    @XmlAttribute(name = "TargetTypeID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    @Id
    @SequenceGenerator(name = "sublink_id_seq", sequenceName = "sublink_id_seq", allocationSize = 1)
    @GeneratedValue(strategy = SEQUENCE, generator = "sublink_id_seq")
    @Column(name="id", nullable = false)
    protected Long targetTypeID;
    @XmlAttribute(name = "DeltaAction")
    @Column(insertable = false, updatable = false)
    protected DeltaActionSchemaType deltaAction;

    


    

}
