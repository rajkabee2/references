package com.gme.hom.auth.models;

public class AccessControlSpec {

}
