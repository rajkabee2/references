package com.gme.hom.sdn.ofac.models.referenceValueSetSchemaType;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "aliasType" })
@Entity @Getter @Setter
public class AliasTypeValues {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@OneToMany( cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	@XmlElement(name = "AliasType")
	protected java.util.List<AliasType> aliasType;


	public java.util.List<AliasType> getAliasType() {
		if (aliasType == null) {
			aliasType = new ArrayList<>();
		}
		return this.aliasType;
	}

}
