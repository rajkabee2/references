package com.gme.hom.auth.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthValidationResponse {
	
	String username;
	
	String address;

}
