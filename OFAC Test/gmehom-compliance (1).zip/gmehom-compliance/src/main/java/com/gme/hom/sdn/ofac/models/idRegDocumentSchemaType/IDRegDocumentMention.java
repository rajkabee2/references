package com.gme.hom.sdn.ofac.models.idRegDocumentSchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.config.ReferenceSchemaType;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <attribute name="IDRegDocumentID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="ReferenceType" use="required" type="{http://www.un.org/sanctions/1.0}ReferenceSchemaType" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@Entity @Getter @Setter
public class IDRegDocumentMention {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @XmlAttribute(name = "IDRegDocumentID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected Long idRegDocumentID;
    @XmlAttribute(name = "ReferenceType", required = true)
    protected ReferenceSchemaType referenceType;
    @XmlAttribute(name = "DeltaAction")
    @Column(insertable = false, updatable = false)
    protected DeltaActionSchemaType deltaAction;

   

}