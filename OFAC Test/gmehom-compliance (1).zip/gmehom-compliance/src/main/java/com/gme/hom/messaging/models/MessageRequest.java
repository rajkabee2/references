package com.gme.hom.messaging.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.gme.hom.common.config.EntityTypeCodes;
import com.gme.hom.messaging.config.MessageStatusCodes;
import com.gme.hom.messaging.config.MessageTypeCodes;
import com.gme.hom.templates.config.MessageTemplateTypeCodes;
import com.gme.hom.users.config.UserAssociationTypeCodes;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MessageRequest {

	@Enumerated(EnumType.STRING)
	@JsonProperty("message_type")
	private MessageTypeCodes messageType;

	@JsonInclude(Include.NON_NULL)
	private String priority;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("contact_info")
	private String contactInfo;

	@JsonInclude(Include.NON_NULL)
	private String cc;

	@JsonInclude(Include.NON_NULL)
	private String bcc;

	@JsonInclude(Include.NON_NULL)
	private String content;

	@JsonInclude(Include.NON_NULL)
	private String subject;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("association_id")
	private long associationId;

	@Enumerated(EnumType.STRING)
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("association_type")
	private UserAssociationTypeCodes associationType;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("source_id")
	private Long sourceId;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("source_type")
	private EntityTypeCodes sourceType;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("message_template_type")
	private MessageTemplateTypeCodes messageTemplateType;

	@Enumerated(EnumType.STRING)
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("status")
	private MessageStatusCodes status;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("schedule_time")
	private java.util.Date scheduleTime;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("schedule_time_utc")
	private java.util.Date scheduleTimeUtc;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("reference")
	private String reference;

}
