package com.gme.hom.sdn.ofac.models.documentedNameSchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "value" })
@Entity
@Getter
@Setter
public class NamePartValue {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@XmlValue
	protected String value;
	@XmlAttribute(name = "NamePartGroupID", required = true)
	@XmlSchemaType(name = "nonNegativeInteger")
	protected Long namePartGroupID;
	@XmlAttribute(name = "ScriptID", required = true)
	@XmlSchemaType(name = "nonNegativeInteger")
	protected Long scriptID;
	@XmlAttribute(name = "ScriptStatusID", required = true)
	@XmlSchemaType(name = "nonNegativeInteger")
	protected Long scriptStatusID;
	@XmlAttribute(name = "Acronym", required = true)
	protected boolean acronym;
	@Column(insertable = false, updatable = false)
	@XmlAttribute(name = "DeltaAction")
	protected DeltaActionSchemaType deltaAction;

	

}
