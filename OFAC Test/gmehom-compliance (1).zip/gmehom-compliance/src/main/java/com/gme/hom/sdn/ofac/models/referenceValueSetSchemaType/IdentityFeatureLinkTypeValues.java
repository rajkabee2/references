package com.gme.hom.sdn.ofac.models.referenceValueSetSchemaType;

import jakarta.persistence.*;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element name="IdentityFeatureLinkType" maxOccurs="unbounded" minOccurs="0">
 *           <complexType>
 *             <simpleContent>
 *               <extension base="<http://www.w3.org/2001/XMLSchema>string">
 *                 <attribute name="ID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </extension>
 *             </simpleContent>
 *           </complexType>
 *         </element>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "identityFeatureLinkType"
})
@Entity
@Getter
@Setter
public class IdentityFeatureLinkTypeValues {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "IdentityFeatureLinkType")
    protected java.util.List<IdentityFeatureLinkType> identityFeatureLinkType;

    /**
     * Gets the value of the identityFeatureLinkType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a {@code set} method for the identityFeatureLinkType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentityFeatureLinkType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceValueSetsSchemaType.IdentityFeatureLinkTypeValues.IdentityFeatureLinkType }
     * 
     * 
     * @return
     *     The value of the identityFeatureLinkType property.
     */
    public java.util.List<IdentityFeatureLinkType> getIdentityFeatureLinkType() {
        if (identityFeatureLinkType == null) {
            identityFeatureLinkType = new ArrayList<>();
        }
        return this.identityFeatureLinkType;
    }


   

}
