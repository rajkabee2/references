package com.gme.hom.users.config;

public enum UserAssociationTypeCodes {
	BUSINESS("BUSINESS"),
	INDIVIDUAL("INDIVIDUAL");
	
	private final String name;

	private UserAssociationTypeCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}

}
