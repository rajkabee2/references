package com.gme.hom.sdn.ofac.models.distinctPartySchemaType;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.Comment;
import com.gme.hom.sdn.ofac.models.featureSchemaType.FeatureSchemaType;
import com.gme.hom.sdn.ofac.models.identitySchemaType.IdentitySchemaType;
import jakarta.persistence.*;
import jakarta.xml.bind.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "comment",
    "identity",
    "feature",
    "sanctionsEntryReference",
    "externalReference"
})
@Entity
@Getter
@Setter
public class Profile {

    @XmlElement(name = "Comment")
    @ElementCollection
    @CollectionTable(name = "profile_comment", joinColumns = @JoinColumn(name = "profile_id"))
    protected List<Comment> comment;

    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "Identity", required = true)
    protected List<IdentitySchemaType> identity;

    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "Feature")
    protected List<FeatureSchemaType> feature;

    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "SanctionsEntryReference")
    protected List<SanctionsEntryReference> sanctionsEntryReference;

    @OneToMany( cascade = CascadeType.ALL, orphanRemoval = true)
    @XmlElement(name = "ExternalReference")
    protected List<ExternalReference> externalReference;
    @XmlAttribute(name = "ID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;
    @XmlAttribute(name = "PartySubTypeID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected Long partySubTypeID;
    @XmlAttribute(name = "DeltaAction")
    protected DeltaActionSchemaType deltaAction;


    public List<Comment> getComment() {
        if (comment == null) {
            comment = new ArrayList<>();
        }
        return this.comment;
    }


    public List<IdentitySchemaType> getIdentity() {
        if (identity == null) {
            identity = new ArrayList<>();
        }
        return this.identity;
    }


    public List<FeatureSchemaType> getFeature() {
        if (feature == null) {
            feature = new ArrayList<>();
        }
        return this.feature;
    }


    public List<SanctionsEntryReference> getSanctionsEntryReference() {
        if (sanctionsEntryReference == null) {
            sanctionsEntryReference = new ArrayList<>();
        }
        return this.sanctionsEntryReference;
    }


    public List<ExternalReference> getExternalReference() {
        if (externalReference == null) {
            externalReference = new ArrayList<>();
        }
        return this.externalReference;
    }

    



    

}