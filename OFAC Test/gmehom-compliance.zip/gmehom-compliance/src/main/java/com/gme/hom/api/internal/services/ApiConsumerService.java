package com.gme.hom.api.internal.services;

import com.gme.hom.api.config.ApiServiceCodes;
import com.gme.hom.api.models.ApiRequest;
import com.gme.hom.api.models.ApiResponse;

import jakarta.servlet.http.Cookie;

public interface ApiConsumerService {
	
	public ApiResponse consumeApi(Cookie [] cookies, ApiServiceCodes apiCode, ApiRequest apiRequest);	

}
