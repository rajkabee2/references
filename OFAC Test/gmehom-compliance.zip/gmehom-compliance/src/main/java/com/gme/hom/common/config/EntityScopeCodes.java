package com.gme.hom.common.config;

public enum EntityScopeCodes {

	SINGLE("SINGLE"), MULTIPLE("MULTIPLE");

	private final String name;

	private EntityScopeCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}

}
