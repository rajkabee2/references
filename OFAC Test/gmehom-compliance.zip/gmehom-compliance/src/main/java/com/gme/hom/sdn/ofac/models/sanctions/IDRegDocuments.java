package com.gme.hom.sdn.ofac.models.sanctions;

import java.util.ArrayList;
import java.util.List;

import com.gme.hom.sdn.ofac.models.idRegDocumentSchemaType.IDRegDocumentSchemaType;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element name="IDRegDocument" type="{http://www.un.org/sanctions/1.0}IDRegDocumentSchemaType" maxOccurs="unbounded" minOccurs="0"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "idRegDocument"
})
public class IDRegDocuments {

    @XmlElement(name = "IDRegDocument")
    protected List<IDRegDocumentSchemaType> idRegDocument;

    /**
     * Gets the value of the idRegDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a {@code set} method for the idRegDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIDRegDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IDRegDocumentSchemaType }
     * 
     * 
     * @return
     *     The value of the idRegDocument property.
     */
    public List<IDRegDocumentSchemaType> getIDRegDocument() {
        if (idRegDocument == null) {
            idRegDocument = new ArrayList<>();
        }
        return this.idRegDocument;
    }

}

