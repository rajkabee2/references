package com.gme.hom.api.internal.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.gme.hom.GlobalConfig;
import com.gme.hom.api.config.ApiServiceCodes;
import com.gme.hom.api.models.ApiRequest;
import com.gme.hom.api.models.ApiResponse;

import jakarta.servlet.http.Cookie;

@Service
public class ApiConsumerServiceImpl implements ApiConsumerService {

	final GlobalConfig globalConfig;

	private static final Logger logger = LoggerFactory.getLogger(ApiConsumerServiceImpl.class);

	ApiConsumerServiceImpl(GlobalConfig globalConfig) {
		this.globalConfig = globalConfig;
	}

	public ApiResponse consumeApi(Cookie[] cookies, ApiServiceCodes apiCode, ApiRequest apiRequest) {

		logger.debug("-->" + new Object() {
		}.getClass().getName() + ":" + new Object() {
		}.getClass().getEnclosingMethod().getName());
		logger.debug(apiCode.toString());
		logger.debug(String.valueOf(apiRequest));

		RestTemplate restTemplate = new RestTemplate();

		if (apiCode == ApiServiceCodes.AUTH) {
			String url = globalConfig.gmeHomServicesAuthUrl;
			String jsonBody = "";

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			if (cookies != null) {

				for (Cookie cookie : cookies) {
					logger.debug(cookie.getName() + "=" + cookie.getValue());
					if (cookie.getName().equals("jwt")) {
						headers.add("Cookie", cookie.getName() + "=" + cookie.getValue());
					}
				}
			}

			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			try {
				jsonBody = ow.writeValueAsString(apiRequest);
			} catch (Exception e) {
				logger.debug(e.getMessage());
				return null;
			}

			HttpEntity<String> request = new HttpEntity<String>(jsonBody, headers);

			logger.debug("httpEnitity:" + String.valueOf(request));

			try {
				// ResponseEntity<ApiResponse> responseEntity = restTemplate.postForEntity(url,
				// request,ApiResponse.class);
				ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
				logger.debug("responseEntity: " + response);
				logger.debug("responseEntity:body: " + response.getBody());

				if (response != null) {

					return new ObjectMapper().readValue(response.getBody(), ApiResponse.class);
				}

			} catch (Exception e) {
				logger.debug(e.getMessage());
				return null;
			}

		} else if (apiCode == ApiServiceCodes.MESSAGING) {
			String url = globalConfig.gmeHomServicesApigatewayUrl + globalConfig.gmeHomServicesMessagingName;
			String jsonBody = "";

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			if (cookies != null) {

				for (Cookie cookie : cookies) {
					logger.debug(cookie.getName() + "=" + cookie.getValue());
					if (cookie.getName().equals("jwt")) {
						headers.add("Cookie", cookie.getName() + "=" + cookie.getValue());
					}
				}
			}

			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			try {
				jsonBody = ow.writeValueAsString(apiRequest);
			} catch (Exception e) {
				logger.debug(e.getMessage());
				return null;
			}

			HttpEntity<String> request = new HttpEntity<String>(jsonBody, headers);

			logger.debug("httpEnitity request before sending: " + String.valueOf(request));

			try {
				// ResponseEntity<ApiResponse> responseEntity = restTemplate.postForEntity(url,
				// request,ApiResponse.class);
				ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
				logger.debug("responseEntity: " + response);
				logger.debug("responseEntity:body: " + response.getBody());

				if (response != null) {

					return new ObjectMapper().readValue(response.getBody(), ApiResponse.class);
				}

			} catch (Exception e) {
				logger.debug(e.getMessage());
				return null;
			}
		}
	

		return null;

	}
}
