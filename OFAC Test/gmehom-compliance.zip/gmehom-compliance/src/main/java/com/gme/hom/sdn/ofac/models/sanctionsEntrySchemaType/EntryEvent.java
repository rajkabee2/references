package com.gme.hom.sdn.ofac.models.sanctionsEntrySchemaType;

import java.math.BigInteger;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.Comment;
import com.gme.hom.sdn.ofac.models.DateSchemaType;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element ref="{http://www.un.org/sanctions/1.0}Comment" minOccurs="0"/>
 *         <element name="Date" type="{http://www.un.org/sanctions/1.0}DateSchemaType"/>
 *       </sequence>
 *       <attribute name="ID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="EntryEventTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="LegalBasisID" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "comment",
    "date"
})
public class EntryEvent {

    @XmlElement(name = "Comment")
    protected Comment comment;
    @XmlElement(name = "Date", required = true)
    protected DateSchemaType date;
    @XmlAttribute(name = "ID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger id;
    @XmlAttribute(name = "EntryEventTypeID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger entryEventTypeID;
    @XmlAttribute(name = "LegalBasisID")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger legalBasisID;
    @XmlAttribute(name = "DeltaAction")
    protected DeltaActionSchemaType deltaAction;


}