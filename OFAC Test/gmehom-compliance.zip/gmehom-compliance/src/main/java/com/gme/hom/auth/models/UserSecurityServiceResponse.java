package com.gme.hom.auth.models;

import com.gme.hom.auth.config.AuthStatusCodes;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserSecurityServiceResponse {
	
	
	AuthStatusCodes authStatusCode;
	
	AuthValidationResponse authResponse;

}
