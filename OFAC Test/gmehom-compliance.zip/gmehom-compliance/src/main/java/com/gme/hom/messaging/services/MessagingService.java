package com.gme.hom.messaging.services;

import com.gme.hom.messaging.models.MessageBody;
import com.gme.hom.messaging.models.MessageRequest;
import com.gme.hom.messaging.models.MessageResponse;


public interface MessagingService {	
	
	public MessageResponse sendMessage(MessageRequest messageRequest, MessageBody messageBody);

}
