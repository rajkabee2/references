package com.gme.hom.sdn.ofac.services;

public interface OfacService {
	
	public void loadXml();

}
