package com.gme.hom.auth.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.gme.hom.api.config.ApiFunctionCodes;
import com.gme.hom.api.config.ApiResponseCodes;
import com.gme.hom.api.config.ApiServiceCodes;
import com.gme.hom.api.internal.services.ApiConsumerService;
import com.gme.hom.api.models.ApiRequest;
import com.gme.hom.api.models.ApiResponse;
import com.gme.hom.auth.config.AuthStatusCodes;
import com.gme.hom.auth.models.AuthValidationResponse;
import com.gme.hom.auth.models.UserSecurityServiceResponse;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

@Service
public class UserSecurityService {

	final ApiConsumerService apiConsumer;

	private static final Logger logger = LoggerFactory.getLogger(UserSecurityService.class);

	UserSecurityService(ApiConsumerService apiConsumer) {
		this.apiConsumer = apiConsumer;
	}

	public UserSecurityServiceResponse getUserValidation(HttpServletRequest httpRequest) {

		logger.debug("-->" + new Object() {
		}.getClass().getName() + ":" + new Object() {
		}.getClass().getEnclosingMethod().getName());
		logger.debug(String.valueOf(httpRequest));

		Cookie[] cookies = httpRequest.getCookies();

		UserSecurityServiceResponse usRes = new UserSecurityServiceResponse();
		ApiRequest apiReq = new ApiRequest();

		apiReq.setFunction(ApiFunctionCodes.VALIDATE);		

		ApiResponse apiRes = apiConsumer.consumeApi(cookies, ApiServiceCodes.AUTH, apiReq);

		if (apiRes.getStatus() == ApiResponseCodes.SUCCESS) {

			AuthValidationResponse authRes = (AuthValidationResponse) apiRes.getAuthValidationResponse();

			usRes.setAuthStatusCode(AuthStatusCodes.AUTHENTICATED);
			usRes.setAuthResponse(authRes);

		} else {
			usRes.setAuthStatusCode(AuthStatusCodes.BAD_CREDENTIALS);

		}

		return usRes;

	}
}
