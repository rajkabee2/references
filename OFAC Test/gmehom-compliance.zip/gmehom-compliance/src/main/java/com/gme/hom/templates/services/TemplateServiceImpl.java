package com.gme.hom.templates.services;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gme.hom.common.services.CustomStringJoiner;
import com.gme.hom.messaging.config.MessageTypeCodes;
import com.gme.hom.templates.config.MessageTemplateTypeCodes;
import com.gme.hom.templates.repository.TemplateDto;
import com.gme.hom.templates.repository.TemplateRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class TemplateServiceImpl implements TemplateService {
	
	@Autowired
	TemplateRepository templateRepository;	
	
	private static final Logger logger = LoggerFactory.getLogger(TemplateServiceImpl.class);
	
	public List<TemplateDto> getAllTemplates() {
		return templateRepository.getAllTemplates();
	}

	@Override
	public TemplateDto getTemplateByTypeAndPurpose(MessageTypeCodes templateType, MessageTemplateTypeCodes purpose) {
		logger.debug("-->" + new Object() {}.getClass().getName() + ":" + new Object() {}.getClass().getEnclosingMethod().getName());
		logger.debug(CustomStringJoiner.joinStrings(Arrays.asList(templateType.toString(), purpose.toString()), ":"));
		
		return templateRepository.getTemplateByTypeAndPurpose(templateType.toString(), purpose.toString());
	}
	
	

}
