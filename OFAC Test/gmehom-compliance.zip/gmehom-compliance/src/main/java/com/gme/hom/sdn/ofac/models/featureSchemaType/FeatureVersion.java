package com.gme.hom.sdn.ofac.models.featureSchemaType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.Comment;
import com.gme.hom.sdn.ofac.models.DatePeriod;
import com.gme.hom.sdn.ofac.models.IDRegDocumentReference;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element ref="{http://www.un.org/sanctions/1.0}Comment" minOccurs="0"/>
 *         <element ref="{http://www.un.org/sanctions/1.0}DatePeriod" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="VersionDetail" maxOccurs="unbounded" minOccurs="0">
 *           <complexType>
 *             <simpleContent>
 *               <extension base="<http://www.w3.org/2001/XMLSchema>string">
 *                 <attribute name="DetailTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                 <attribute name="DetailReferenceID" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </extension>
 *             </simpleContent>
 *           </complexType>
 *         </element>
 *         <element name="VersionLocation" maxOccurs="unbounded" minOccurs="0">
 *           <complexType>
 *             <complexContent>
 *               <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 <attribute name="LocationID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </restriction>
 *             </complexContent>
 *           </complexType>
 *         </element>
 *         <element ref="{http://www.un.org/sanctions/1.0}IDRegDocumentReference" maxOccurs="unbounded" minOccurs="0"/>
 *       </sequence>
 *       <attribute name="ID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="ReliabilityID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "comment",
    "datePeriod",
    "versionDetail",
    "versionLocation",
    "idRegDocumentReference"
})
public class FeatureVersion {

    @XmlElement(name = "Comment")
    protected Comment comment;
    @XmlElement(name = "DatePeriod")
    protected List<DatePeriod> datePeriod;
    @XmlElement(name = "VersionDetail")
    protected List<VersionDetail> versionDetail;
    @XmlElement(name = "VersionLocation")
    protected List<VersionLocation> versionLocation;
    @XmlElement(name = "IDRegDocumentReference")
    protected List<IDRegDocumentReference> idRegDocumentReference;
    @XmlAttribute(name = "ID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger id;
    @XmlAttribute(name = "ReliabilityID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger reliabilityID;
    @XmlAttribute(name = "DeltaAction")
    protected DeltaActionSchemaType deltaAction;


    /**
     * Gets the value of the datePeriod property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a {@code set} method for the datePeriod property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDatePeriod().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DatePeriod }
     * 
     * 
     * @return
     *     The value of the datePeriod property.
     */
    public List<DatePeriod> getDatePeriod() {
        if (datePeriod == null) {
            datePeriod = new ArrayList<>();
        }
        return this.datePeriod;
    }

    /**
     * Gets the value of the versionDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a {@code set} method for the versionDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVersionDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeatureSchemaType.FeatureVersion.VersionDetail }
     * 
     * 
     * @return
     *     The value of the versionDetail property.
     */
    public List<VersionDetail> getVersionDetail() {
        if (versionDetail == null) {
            versionDetail = new ArrayList<>();
        }
        return this.versionDetail;
    }

    /**
     * Gets the value of the versionLocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a {@code set} method for the versionLocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVersionLocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeatureSchemaType.FeatureVersion.VersionLocation }
     * 
     * 
     * @return
     *     The value of the versionLocation property.
     */
    public List<VersionLocation> getVersionLocation() {
        if (versionLocation == null) {
            versionLocation = new ArrayList<>();
        }
        return this.versionLocation;
    }

    /**
     * Gets the value of the idRegDocumentReference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a {@code set} method for the idRegDocumentReference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIDRegDocumentReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IDRegDocumentReference }
     * 
     * 
     * @return
     *     The value of the idRegDocumentReference property.
     */
    public List<IDRegDocumentReference> getIDRegDocumentReference() {
        if (idRegDocumentReference == null) {
            idRegDocumentReference = new ArrayList<>();
        }
        return this.idRegDocumentReference;
    }

    


   


    

}
