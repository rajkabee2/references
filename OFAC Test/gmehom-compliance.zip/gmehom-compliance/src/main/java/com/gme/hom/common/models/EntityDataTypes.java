package com.gme.hom.common.models;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.gme.hom.common.config.EntityTypeCodes;

public final class EntityDataTypes {
	
	public static final Map<EntityTypeCodes, String> entityDataTypes;
	static {
		Map<EntityTypeCodes, String> newMap = new HashMap<EntityTypeCodes, String>();
		newMap.put(EntityTypeCodes.MERCHANT, "Merchant");
		newMap.put(EntityTypeCodes.USER_SIGNUP, "Users Signup");	
		newMap.put(EntityTypeCodes.USERS, "User");
		newMap.put(EntityTypeCodes.CATEGORIES, "Category");
		entityDataTypes = Collections.unmodifiableMap(newMap);
	}	

}
