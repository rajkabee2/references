package com.gme.hom.api.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.gme.hom.messaging.models.MessageBody;
import com.gme.hom.messaging.models.MessageRequest;

import jakarta.validation.Valid;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ApiData {

	@Valid
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("query_params")
	private ApiRequestQueryParams query;

	@Valid
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("body")
	private String body;
	
	@Valid
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("message")
	private MessageRequest messageRequest;
	
	@Valid
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("message_body")
	private MessageBody messageBody;

}
