package com.gme.hom.testService.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestResponse {
	
	String org;
	String system;
	Integer counter;

}
