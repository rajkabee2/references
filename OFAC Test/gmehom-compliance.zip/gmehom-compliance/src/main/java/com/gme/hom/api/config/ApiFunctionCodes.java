package com.gme.hom.api.config;

public enum ApiFunctionCodes {
	// authentication
	AUTHENTICATE("AUTHENTICATE"),

	// common
	SEARCH("SEARCH"), ADD_DATA("ADD_DATA"), UPDATE_DATA("UPDATE_DATA"), VALIDATE("VALIDATE"),

	GENERATE("GENERATE"), CHECK_DUPLICATE("CHECK_DUPLICATE"), CALCULATE_HASH("CALCULATE_HASH"),
	SEND_MESSAGE("SEND_MESSAGE"), UPLOAD("UPLOAD"),

	// password management
	SETTING_PASSWORD("SETTING_PASSWORD"),

	// user signup
	SIGNUP_REQUEST("SIGNUP_REQUEST"), REQUEST_OTP("REQUEST_OTP"), VALIDATE_OTP("VALIDATE_OTP"), ADD_PHONE("ADD_PHONE"),
	SET_PASSWORD("SET_PASSWORD");

	private final String name;

	private ApiFunctionCodes(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}
}