package com.gme.hom.sdn.ofac.models.idRegDocumentSchemaType;

import java.math.BigInteger;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.DatePeriod;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element ref="{http://www.un.org/sanctions/1.0}DatePeriod"/>
 *       </sequence>
 *       <attribute name="IDRegDocDateTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "datePeriod"
})
public class DocumentDate {

    @XmlElement(name = "DatePeriod", required = true)
    protected DatePeriod datePeriod;
    @XmlAttribute(name = "IDRegDocDateTypeID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger idRegDocDateTypeID;
    @XmlAttribute(name = "DeltaAction")
    protected DeltaActionSchemaType deltaAction;


}
