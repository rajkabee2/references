package com.gme.hom.sdn.ofac.models.identitySchemaType;

import java.math.BigInteger;
import java.util.List;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.Comment;
import com.gme.hom.sdn.ofac.models.DatePeriod;
import com.gme.hom.sdn.ofac.models.documentedNameSchemaType.DocumentedNameSchemaType;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element ref="{http://www.un.org/sanctions/1.0}Comment" minOccurs="0"/>
 *         <element ref="{http://www.un.org/sanctions/1.0}DatePeriod" minOccurs="0"/>
 *         <element name="DocumentedName" type="{http://www.un.org/sanctions/1.0}DocumentedNameSchemaType" maxOccurs="unbounded"/>
 *       </sequence>
 *       <attribute name="FixedRef" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       <attribute name="AliasTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="Primary" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       <attribute name="LowQuality" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "comment",
    "datePeriod",
    "documentedName"
})
public class Alias {

    @XmlElement(name = "Comment")
    protected Comment comment;
    @XmlElement(name = "DatePeriod")
    protected DatePeriod datePeriod;
    @XmlElement(name = "DocumentedName", required = true)
    protected List<DocumentedNameSchemaType> documentedName;
    @XmlAttribute(name = "FixedRef", required = true)
    protected String fixedRef;
    @XmlAttribute(name = "AliasTypeID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger aliasTypeID;
    @XmlAttribute(name = "Primary", required = true)
    protected boolean primary;
    @XmlAttribute(name = "LowQuality", required = true)
    protected boolean lowQuality;
    @XmlAttribute(name = "DeltaAction")
    protected DeltaActionSchemaType deltaAction;

   

}
