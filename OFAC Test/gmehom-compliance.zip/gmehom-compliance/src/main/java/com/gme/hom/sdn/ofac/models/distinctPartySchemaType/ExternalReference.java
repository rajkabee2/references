package com.gme.hom.sdn.ofac.models.distinctPartySchemaType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.gme.hom.sdn.ofac.config.DeltaActionSchemaType;
import com.gme.hom.sdn.ofac.models.Comment;
import com.gme.hom.sdn.ofac.models.DirectURL;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element ref="{http://www.un.org/sanctions/1.0}Comment" minOccurs="0"/>
 *         <element name="ExRefValue" minOccurs="0">
 *           <complexType>
 *             <simpleContent>
 *               <extension base="<http://www.w3.org/2001/XMLSchema>string">
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </extension>
 *             </simpleContent>
 *           </complexType>
 *         </element>
 *         <element ref="{http://www.un.org/sanctions/1.0}DirectURL" minOccurs="0"/>
 *         <element name="SubLink" maxOccurs="unbounded" minOccurs="0">
 *           <complexType>
 *             <complexContent>
 *               <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 <sequence>
 *                   <element name="Description" minOccurs="0">
 *                     <complexType>
 *                       <simpleContent>
 *                         <extension base="<http://www.w3.org/2001/XMLSchema>string">
 *                           <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *                         </extension>
 *                       </simpleContent>
 *                     </complexType>
 *                   </element>
 *                   <element ref="{http://www.un.org/sanctions/1.0}DirectURL"/>
 *                 </sequence>
 *                 <attribute name="TargetTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                 <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *               </restriction>
 *             </complexContent>
 *           </complexType>
 *         </element>
 *       </sequence>
 *       <attribute name="ExRefTypeID" use="required" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *       <attribute name="DeltaAction" type="{http://www.un.org/sanctions/1.0}DeltaActionSchemaType" />
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "comment",
    "exRefValue",
    "directURL",
    "subLink"
})
public class ExternalReference {

    @XmlElement(name = "Comment")
    protected Comment comment;
    @XmlElement(name = "ExRefValue")
    protected ExRefValue exRefValue;
    @XmlElement(name = "DirectURL")
    protected DirectURL directURL;
    @XmlElement(name = "SubLink")
    protected List<SubLink> subLink;
    @XmlAttribute(name = "ExRefTypeID", required = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger exRefTypeID;
    @XmlAttribute(name = "DeltaAction")
    protected DeltaActionSchemaType deltaAction;

 
   

 

    /**
     * Gets the value of the subLink property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a {@code set} method for the subLink property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubLink().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DistinctPartySchemaType.Profile.ExternalReference.SubLink }
     * 
     * 
     * @return
     *     The value of the subLink property.
     */
    public List<SubLink> getSubLink() {
        if (subLink == null) {
            subLink = new ArrayList<>();
        }
        return this.subLink;
    }

   


    


   

}
